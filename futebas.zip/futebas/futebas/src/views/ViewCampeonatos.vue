<template>
  <h1>Os Campeonatos</h1>
  <CardCampeonato
  v-for="item in arrCamps" v-bind:key="item.id"
  :campeonato="item"/>
</template>

<script>
import CardCampeonato from '@/components/CardCampeonato.vue'
export default {
  name: 'ViewCampeonatos',
  components: { CardCampeonato },
  data() {
    return {
      arrCamps: Array,
    }
  },
  created() {
    fetch('http://localhost:3000/campeonatos')
      .then((response) => {
        response
          .json()
          .then((data) => {
            this.arrCamps = data
          })
          .catch((error) => console.log(error))
      })
      .catch((e) => console.log(e.message))
  },
}
</script>

<style></style>
