<template>
  <button @click="mostrar = !mostrar" :class="mostrar ? 'vermelho' : 'verde'">
    {{ mostrar ? 'Esconder' : 'Mostrar' }}
  </button>
  <ul v-if="mostrar">
    <li>Inter</li>
    <li>Grêmio</li>
    <li>Juventude</li>
    <li>Flamengo</li>
  </ul>
</template>

<script>
export default {
  name: 'DetalheTimes',
  data() {
    return {
      mostrar: false,
    }
  },
}
</script>

<style>
  .vermelho{
    color:red
  }
  .verde{
    color:green
  }
</style>
