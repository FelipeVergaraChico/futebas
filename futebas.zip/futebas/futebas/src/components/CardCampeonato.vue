<template>
    <div class="card">
        <h3>{{ campeonato.nome }} {{ campeonato.temporada }}</h3>
        {{  campeonato.tipo }} {{ campeonato.regiao }}
        <br />
        <DetalheTimes />
    </div>
</template>

<script>
import DetalheTimes from './DetalheTimes.vue'
    export default {
        name: "CardCampeonato",
        components: {DetalheTimes},
        props: {
            campeonato: Object
        }
    }
</script>

<style>
    .card{
        border: 1px solid white;
        padding: 10px;
        margin: 20px;
    }
</style>