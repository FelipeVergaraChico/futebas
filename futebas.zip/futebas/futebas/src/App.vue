<script setup>
import { RouterLink, RouterView } from 'vue-router'
import CardCampeonato from './components/CardCampeonato.vue';
</script>

<template>
    Hello World!
  <RouterView />
</template>

<script>
export default {
  name: "App"
}
</script>

<style scoped>

</style>
